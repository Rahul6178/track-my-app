# ticToe
ticToe is a basic and pretty simple multiplayer tic tac toe game implemented through SFML and OpenGL for learning purposes.
The task has been undertaken as an assignment in Object Oriented Programming course.
