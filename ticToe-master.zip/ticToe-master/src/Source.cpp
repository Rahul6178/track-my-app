#include "Graphics.h"

int main()
{
	Graphics ticTac;
	ticTac.get_board();

	return 0;
}
